# FRZK – Kapitel 2: Quellenpaket (10.11.2026)

## Inhalt

- `FRZK_Kapitel2_Literaturpruefung_STRIKT_2026-11-10.xlsx`: Hauptregister in acht Tabellenblättern, mit Prüfergebnissen, allen 143 Quellenverwendungen und der Werkzuordnung.
- `FRZK_K2_Quelleninventar_STRIKT_2026-11-10.csv`: 137 unterschiedliche Kapitel-2-Werke; Angaben aus dem Manuskript, vorläufige globale Nummer, Prüfstatus.
- `FRZK_K2_Zitatpruefung_STRIKT_2026-11-10.csv`: jede der 143 Fundstellen mit Absatzindex (0-basiert), Quelle, bisheriger Nummer, vorgeschlagener Nummer und gesondertem Belegstatus.
- `FRZK_K2_Nummernkonflikte_STRIKT_2026-11-10.csv`: neun K1/K2-Nummernkollisionen, sechs interne K2-Nummernkollisionen, zwei unnummerierte Quellen.
- `FRZK_K2_Werkdubletten_STRIKT_2026-11-10.csv`: sechs K2-interne Werkdubletten sowie acht Überschneidungen mit K1.
- `FRZK_K2_Externe_Pruefnachweise_2026-11-10.csv`: 12 unabhängig abgeglichene Publikationen, mit Zugangs- und Prüfgrenzen.
- `FRZK_K2_Originalstellen_3_Einzelbelege_2026-11-10.csv`: drei lokalisiert geprüfte Original-Aussagen, ohne pauschale Freigabe des gesamten Werks.
- `FRZK_K2_Quellen_STAGING_2026-11-10.sql`: getrennte, nichtdestruktive Datenbank-Stagingtabellen.
- `FRZK_K2_Quellenpruefung_Arbeitsbericht_2026-11-10.md`: Befundbericht, Protokoll und weiter offene Schritte.
- `FRZK_K2_Quellen_Kennzahlen_STRIKT_2026-11-10.json`: summarische Kontrolle.

## SQL-Import (MariaDB)

1. Von `frzk_dissertation` ein vollständiges Backup erstellen.
2. In phpMyAdmin die Datenbank **`frzk_dissertation`** auswählen.
3. Die Datei `FRZK_K2_Quellen_STAGING_2026-11-10.sql` importieren.
4. Kontrollieren: `SELECT COUNT(*) FROM frzk_k2_source_staging;` (Soll 137), `SELECT COUNT(*) FROM frzk_k2_citation_staging;` (Soll 143).
5. Die staging-Daten **nicht** automatisch in die produktiven Tabellen `sources`, `citations` und `chapters` übernehmen. Dafür ist ein separater migrationssicherer Import erforderlich.

## Statuswarnung

- Der Neuaufbau von Kapitel 2 ist mit diesem Paket noch **nicht** abgeschlossen.
- Die vollständige externe Originaltextprüfung aller 137 Werke ist **noch offen**. Es wurden 12 bibliografisch oder weitergehend geprüft, davon drei bestimmte Einzelbehauptungen per Originaltext zugeordnet.
- `EINZELSTELLE_PASS` gilt nur für die ausdrücklich geprüfte Aussage und den angegebenen Fundort, **nicht** für die gesamte Veröffentlichung oder für andere Aussagen derselben Quelle.
- Alle Quellennummern ab [24] sind ein Vorschlag zur konfliktfreien Zusammenführung mit Kapitel 1.
