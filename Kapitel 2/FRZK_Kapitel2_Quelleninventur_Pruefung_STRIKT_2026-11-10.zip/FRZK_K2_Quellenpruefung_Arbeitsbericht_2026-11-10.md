# FRZK Dissertation – Kapitel 2: Inventur und Literaturfreigabe

**Prüfdatum:** 10.11.2026  
**Prüfverfahren:** Strenge Freigabe, quellengenau und behauptungsbezogen  
**Grundlage:** `FRZK_Kapitel2_VOLLTEXT_NEUAUFBAU_2026-10-25_REVIEW.docx`, `FRZK_Kapitel1_Iterativer_Erkenntnisprozess_2026-11-09.docx`, `Uebergabe_Kapitel2(1).md`, `frzk_dissertation_stand_ende_kapitel_1.sql`.

## Status und Freigaberegel

Eine ISBN/DOI-Registrierung bestätigt lediglich eine bibliografische Identität, keine spezielle Lehr-/Forschungsaussage. Eine Originalstelle gilt nur für die präzise geprüfte Behauptung. Bestehende Bestandsstatus aus Kapitel 1 werden nicht automatisch für die neue Verwendung übernommen. Alle ungeprüften Aussagen bleiben gesperrt.

## Vollständige Inventur des vorhandenen Manuskripts

- Zitierverwendungen im Kapitel 2: **143**, davon 141 numerisch und 2 ohne endgültige Nummer (Hinds 1999/2001).
- Verwendete alte Nummern: **135** im Bereich [15]–[149]; die Nummern [142]–[147] bezeichnen jeweils zwei unterschiedliche Werke.
- Tatsächliche unterschiedliche Werke in Kapitel 2 nach dem Abgleich: **137**; insgesamt **6** mehrfach angelegte K2-Werke.
- Kapitel-1-Quellen im hochgeladenen SQL-Stand: **23**. Davon erscheinen **8** als Werke ebenfalls im Kapitel-2-Text.
- Neue Werke für Kapitel 2: **129**. Globaler Quellenbestand nach konsistenter Neunummerierung: **152** (vorläufig).
- Alte Nummernkollisionen zwischen Kapitel 1 und Kapitel 2: **9** ([15]–[23]).
- DOI-Angabe im Manuskript bei **96** von 137 einzigartigen Kapitel-2-Werken vorhanden; bei **41** fehlt sie im Manuskript. Eine fehlende DOI-Angabe bedeutet nicht zwangsläufig, dass die Veröffentlichung keine DOI besitzt.

## Externe Quellenprüfung: erstes abgeschlossenes Teilprotokoll

Von 137 identifizierten Werken konnten bisher für **12** externe Publikationsdatensätze identifiziert und abgeglichen werden. Bei **3** konkreten Teilbehauptungen wurde eine zugängliche Originalstelle mit einem nachvollziehbaren Locator geprüft. **134** Quellen sind weiterhin für nicht gesondert geprüfte Belegverwendungen gesperrt. Diese Zahlen sagen nichts über die noch vollständig ausstehende Prüfung der übrigen Werke aus.

| Alter Verweis | Quelle | Prüffundort | Ergebnis |
|---|---|---|---|
| [15] | Grant & Booth (2009) | Abstract; Method; Results; Tabelle 1; Conclusion | EINZELSTELLE_PASS – nur begrenzte Teilbehauptung |
| [18] | Page et al. (2021) | Abstract; Tabelle 1, insbesondere Items 5–16 | EINZELSTELLE_PASS – nur begrenzte Teilbehauptung |
| [21] | Blum (2015) | Students’ Modelling Activities; Step 1, 2, 6 | EINZELSTELLE_PASS – nur begrenzte Teilbehauptung |

### Nachweise für die ersten Einzelstellen

**[15] Grant & Booth (2009):** Die Autoren untersuchen 14 Reviewtypen nach Recherche, Bewertung, Synthese und Analyse (SALSA); die Typen sind nicht durchgängig trennscharf.  
Originalfundort: Abstract; Method; Results; Tabelle 1; Conclusion.  
Quelle: https://onlinelibrary.wiley.com/doi/full/10.1111/j.1471-1842.2009.00848.x.  
Grenze: Nur diese umgrenzte Teilbehauptung. Keine pauschale Freigabe sämtlicher Aussagen, die sich auf die Quelle beziehen.

**[18] Page et al. (2021):** PRISMA 2020 ist eine Berichtsleitlinie für systematische Reviews; die Checkliste behandelt u. a. Suche, Studienauswahl und Ergebnissynthese.  
Originalfundort: Abstract; Tabelle 1, insbesondere Items 5–16.  
Quelle: https://www.bmj.com/content/372/bmj.n71.full.  
Grenze: Die Quelle bestätigt Anforderungen für systematische Reviews, nicht die Einstufung der FRZK-Arbeit als systematisches Review.

**[21] Blum (2015):** Blum unterscheidet typische Phasen mathematischer Modellierungsprozesse und behandelt Schwierigkeiten beim Situationsverständnis, Vereinfachen und Validieren.  
Originalfundort: Students’ Modelling Activities; Step 1, 2, 6.  
Quelle: https://link.springer.com/chapter/10.1007/978-3-319-12688-3_9.  
Grenze: Nur diese Teilbehauptung über die Modellierungsphasen; die Übertragung auf FRZK bleibt Eigeninterpretation.

## Verfügbare, aber noch nicht originalstellengeprüfte Publikationen

Erste Verlags-/Registerabgleiche sind dokumentiert für Snyder (2019), Torraco (2005), Greefrath/Vorhölter (2016), Blum/Leiß (2007), Galbraith/Stillman (2006), IEEE 754-2019, Goldberg (1991), Hinds (1999) und Hinds/Patterson/Pfeffer (2001). Die Zugänglichkeit eines Abstracts, einer Verlagsbeschreibung oder eines redaktionell bearbeiteten Nachdrucks reicht unter der strengen Freigaberegel **nicht** für einen inhaltlichen Belegstatus aus. Die 1991er Goldberg-Arbeit wurde z. B. bei ACM identifiziert, der bei Oracle verfügbare Text ist ausdrücklich ein bearbeiteter Nachdruck.

## Nummernkonflikte und Umstellung

1. Die Quellen [1]–[23] von Kapitel 1 bleiben ohne Änderung ihrer Identität und Nummerierung.
2. Die alten Kapitel-2-Nummern [15]–[23] kollidieren mit neun anderen K1-Werken und müssen neu zugeordnet werden.
3. Die K2-Nummern [142]–[147] sind je doppelt vergeben, teilweise für fachlich völlig verschiedene Veröffentlichungen. Keine dieser Nummern darf ohne Rückgriff auf Werk und Absatz automatisch ersetzt werden.
4. Sechs Werke werden in K2 wiederholt aufgeführt (darunter IEEE 754-2019, Goldberg 1991 und Lesh/Doerr 2003); die Zusammenführung erfolgt anhand Werkidentität, nicht allein anhand der Nummer.
5. Acht K2-Werke kommen bereits in K1 vor; sie übernehmen nach Werkabgleich die bestehende K1-Quellennummer.
6. Die neu vorgeschlagenen Nummern [24]–[152] sind **nicht** bereits in `sources` importiert und noch keine Freigabe für die Volltext-Neufassung.

## Datenbankanbindung

Die mitgelieferte Staging-SQL-Datei erstellt nur zwei **neue** Tabellen `frzk_k2_source_staging` und `frzk_k2_citation_staging` im aktuell ausgewählten Schema. Sie verändert weder `chapters`, `sources`, `citations` noch andere Bestandsobjekte von Kapitel 1. Der Import muss in der richtigen Datenbank (`frzk_dissertation`) und nach Datenbanksicherung stattfinden. Der Original-SQL-Export zeigt MariaDB 10.4.32; die Staging-Syntax ist darauf ausgelegt. Eine tatsächliche Ausführung am Nutzerserver wurde nicht vorgenommen.

## Prüflücken und nächste fachliche Schritte

- Verbleibende Werke einzeln anhand autoritativer bibliografischer Register und Originaltexte prüfen; DOI-, Editions- und Seitenangaben abgleichen.
- Für jeden belegten Satz den tatsächlich geprüften Originalfundort, die relevante Aussage und deren Anwendungsgrenze dokumentieren.
- Gegenbelege und kritische Forschung ergänzen, statt nur die Passung zum FRZK zu bestätigen.
- Methodische Grundlagen und didaktische Wirkungsforschung klar von besonderen FRZK-Grenzwert-/Null-/Vektorerweiterungen trennen.
- Danach den Volltext 2.0–2.10 ausschließlich auf tragfähiger Quellenbasis neu verfassen. Vorher bleibt Kapitel 2 im Arbeitsstatus.

**Qualitätssicherungsgrenze:** Die vollständige automatische Bestandsaufnahme ist abgeschlossen. Eine vollständige externe Originaltext-Prüfung sämtlicher 137 Werke ist zu diesem Zeitpunkt **nicht** abgeschlossen. Drei konkrete Einzelbehauptungen wurden nach Quellenabgleich separat freigegeben; dies ist keine pauschale wissenschaftliche Freigabe ganzer Werke oder Kapitel.
